Just the SQLite-pendant to the nice ADO-based Demo on:
http://www.vbforums.com/showthread.php?726339-VB6-SQL-Parameters-Example

It depends on the SQLite-wrapper which comes with the RichClient-Framework
(download from: http://www.vbRichClient.com/#/en/Downloads.htm)

The demo here has one Command-Object less than the original (it only shows,  
how to define and use an Insert-Command + Parameters) - but Update-Commands 
would've been possible too - it's just that dealing directly with the inherent 
Update-Features of an Rs is - especially within Forms, which are already based 
on (or "bound-to") a single one - somewhat less code and easier to deal with.

Also added to the "feature-list" was AddNew- and Delete-Handling on 
the Form, as well as an OpenFile-Dialog, to be able to handle any 
Image-Addition/Replacement the user might want...

So the little Form allows now the complete range of Read/Write-Handling
one typically needs, against a given (small) DB-table... just keep in mind,   
that all the Updates/AddNews/Deletes happen instantly - "no questions asked" - 
that's perhaps something one might want to change, when the approach gets 
widened or adapted to a real scenario...

Olaf Schmidt